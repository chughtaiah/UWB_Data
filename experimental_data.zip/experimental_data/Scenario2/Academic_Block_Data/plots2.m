close all

GT = readtable('GTC2.csv','HeaderLines',1);
Rng = readtable('Range2.csv','HeaderLines',1); 
An = readtable('AC2.csv','HeaderLines',1);

GT = table2array(GT);
Rng = table2array(Rng);
Rng=Rng(:,2:end);
An = table2array(An);

%% plotting the actual ranges
AP = zeros(11,46);
for j = 1: 11
    for i = 1:46
        AP(j,i) = norm(An(j,2:4) - GT(i,2:4));
    end
end

err=(AP(:,:)-Rng(:,:)');

 for k = 1: 11
      figure
%      subplot(6,2,k); 
     plot(AP(k,:))
     hold on
     plot(Rng(:,k),'o')
     title(['For anchor ',num2str(k)])
     legend('Real Range','Measured Range')
 end
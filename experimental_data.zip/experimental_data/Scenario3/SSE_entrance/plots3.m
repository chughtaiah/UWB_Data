close all

GT = readtable('GTC3.csv','HeaderLines',1);
Rng = readtable('Range3.csv','HeaderLines',1); 
An = readtable('AC3.csv','HeaderLines',1);

GT = table2array(GT);
Rng = table2array(Rng);
Rng=Rng(:,2:end);
% Rng=flip(Rng)
An = table2array(An);
% An=flip(An);
% GT=flip(GT);

%% plotting the actual ranges
AP = zeros(11,41);
for j = 1: 11
    for i = 1:41
        AP(j,i) = norm(An(j,2:4) - GT(i,2:4));
    end
end

err=(AP(:,:)-Rng(:,:)');

 for k = 1: 11
      figure
%      subplot(6,2,k); 
     plot(AP(k,:))
     hold on
     plot(Rng(:,k),'o')

     title(['For anchor ',num2str(k)])
     legend('Range Ground Truth','Measured Range')
 end